//
//  main.cpp
//  processAndResourceControler
//
//  Created by DaiRuidong on 1/23/17.
//  Copyright © 2017 RuidongDai. All rights reserved.
//

#include <iostream>
#include "Manager.hpp"

int main(int argc, const char * argv[]) {
    Manager m;
    m.shell();
    return 0;
}