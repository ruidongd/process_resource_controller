//
//  Resource.hpp
//  processAndResourceControler
//
//  Created by DaiRuidong on 1/24/17.
//  Copyright © 2017 RuidongDai. All rights reserved.
//

#ifndef Resource_hpp
#define Resource_hpp
#include "Process.hpp"



#endif /* Resource_hpp */
